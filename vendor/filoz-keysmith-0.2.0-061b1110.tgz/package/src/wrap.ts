/**
 * Sharing: wrap a node key to a recipient's public key.
 *
 * ECDH-ES over secp256k1 plus AES-256-GCM, so a recipient uses the key they
 * already have — a session key, or any service holding a local key — and
 * nothing new has to be published, registered or stored.
 *
 * A grant proves nothing about who made it. Anyone can address one to anyone,
 * with any key inside; what the recipient learns on a successful unwrap is
 * only that the descriptor was not altered in transit. Check a key before
 * writing with it: a group key against the dataset's `foc/kc` with
 * `matchesCommitment`, and a group's key by opening a known piece.
 *
 * @module
 */
import { mapHashToField } from '@noble/curves/abstract/modular.js'
import { secp256k1 } from '@noble/curves/secp256k1.js'
import { hkdf } from '@noble/hashes/hkdf.js'
import { sha256 } from '@noble/hashes/sha2.js'
import { utf8ToBytes } from '@noble/hashes/utils.js'
import { decode, encode } from 'cborg'
import type { Address, Hex } from 'viem'
import { bytesToHex, hexToBytes, isAddress } from 'viem'
import { assertFormatVersion, canonicalNode, groupKeyId, text } from './derive.ts'
import type { Grant, GrantDescriptor } from './types.ts'

/**
 * A decoded grant. Text-keyed fields such as `pieceCid` are informational and unauthenticated, so
 * treat them as untrusted. Only `pieceCid` is typed: there is deliberately no index signature, so
 * a misspelled field is a compile error rather than a silent `undefined`.
 * Any other informational key is present at runtime; narrow it from `Reflect.get(grant, key)`.
 */
export type DecodedGrant = Grant & { pieceCid?: unknown }

const ECDH_INFO = utf8ToBytes('foc/acl/ecdh/v2')
const WRAP_INFO = utf8ToBytes('foc/acl/wrap/v2')
const ALG = 'ECDH-ES+A256GCM/secp256k1'
const KEY_LENGTH = 32

/** CBOR map keys of an encoded grant. Text keys are informational. */
const FIELD = { v: 0, node: 1, owner: 2, groupKeyId: 3, epk: 4, iv: 5, ct: 6 } as const

/** Grants may arrive from anywhere, so enforce only canonical, unambiguous CBOR. */
const STRICT = {
  strict: true,
  useMaps: true,
  rejectDuplicateMapKeys: true,
  allowIndefinite: false,
  allowUndefined: false,
  allowBigInt: false,
} as const

/**
 * The key-agreement key derived from a signing key, so that one credential
 * never serves two algorithms. HKDF stretches the signing key to 48 bytes,
 * and hash-to-scalar (FIPS 186-5 §A.2.1) reduces that to a uniform scalar.
 * Deterministic, so the public half can be published once and stays valid.
 *
 * @throws If it is not a valid secp256k1 private key — an address or a public
 * key passed by mistake would otherwise hash to a key nobody holds.
 */
function ecdhSecretKey(privateKey: Hex): Uint8Array {
  const raw = hexToBytes(privateKey)
  if (raw.length !== 32 || !secp256k1.utils.isValidSecretKey(raw)) {
    throw new Error(`Expected a 32-byte secp256k1 private key, got ${raw.length} bytes that are not one`)
  }
  const seed = hkdf(sha256, raw, undefined, ECDH_INFO, 48)
  return mapHashToField(seed, secp256k1.Point.CURVE().n)
}

/**
 * The public key a sender wraps to, for the holder of a secp256k1 private key.
 *
 * This is the derived key-agreement key, not the signing key's own public
 * point: publish this, not the address key.
 */
export const publicKeyOf = (privateKey: Hex): Hex =>
  bytesToHex(secp256k1.getPublicKey(ecdhSecretKey(privateKey), false))

/**
 * Wrap a node key — a group key, a group's key, or one piece's key — to a recipient.
 *
 * The descriptor is authenticated, so a grant cannot be relabelled as one
 * naming a different group key, group or piece. The result is inert without the
 * recipient's private key, so it can be delivered or stored anywhere.
 *
 * The grant carries the descriptor in canonical form, whoever built it, and
 * nothing else: add informational fields to the returned grant if needed.
 */
export async function wrapTo(recipientPublicKey: Hex, key: Uint8Array, input: GrantDescriptor): Promise<Grant> {
  const descriptor = canonical(input)
  if (key.length !== KEY_LENGTH) {
    throw new Error(`Expected a ${KEY_LENGTH}-byte node key, got ${key.length} bytes`)
  }
  // Accept either encoding, but derive from one, or the two sides would disagree.
  const pkR = secp256k1.Point.fromBytes(hexToBytes(recipientPublicKey)).toBytes(false)
  const ephemeral = secp256k1.utils.randomSecretKey()
  const epk = secp256k1.getPublicKey(ephemeral, false)
  const kek = wrapKek(sharedSecret(ephemeral, pkR), epk, pkR)
  const iv = new Uint8Array(12)
  crypto.getRandomValues(iv)
  const aesKey = await crypto.subtle.importKey('raw', buffer(kek), 'AES-GCM', false, ['encrypt'])
  const ct = await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv: buffer(iv), additionalData: aad(descriptor) },
    aesKey,
    buffer(key)
  )
  return {
    ...descriptor,
    alg: ALG,
    epk: bytesToHex(epk),
    iv: bytesToHex(iv),
    ct: bytesToHex(new Uint8Array(ct)),
  }
}

/**
 * Open a grant with the recipient's private key: the grant as delivered, in
 * bytes, or as decoded by {@link decodeGrant}.
 *
 * @throws If the grant was not addressed to this key, its descriptor was
 * altered, or it is not a grant this version understands.
 */
export async function unwrapWith(privateKey: Hex, input: Grant | Uint8Array): Promise<Uint8Array> {
  const grant = input instanceof Uint8Array ? decodeGrant(input) : input
  if (grant == null || typeof grant !== 'object') {
    throw new Error(`A grant must be an object, got ${grant === null ? 'null' : typeof grant}`)
  }
  const { alg, epk, iv, ct, ...rest } = grant
  const descriptor = canonical(rest)
  if (alg !== ALG) {
    throw new Error(`Unsupported grant algorithm: ${String(alg)}`)
  }
  // Exactly the sizes wrapTo writes: an uncompressed point, a GCM nonce, a node key and its tag.
  const epkBytes = grantBytes(epk, 'epk', 65)
  const ivBytes = grantBytes(iv, 'iv', 12)
  const ctBytes = grantBytes(ct, 'ct', KEY_LENGTH + 16)
  const sk = ecdhSecretKey(privateKey)
  const pkR = secp256k1.getPublicKey(sk, false)
  const kek = wrapKek(sharedSecret(sk, epkBytes), epkBytes, pkR)
  const aesKey = await crypto.subtle.importKey('raw', buffer(kek), 'AES-GCM', false, ['decrypt'])
  try {
    return new Uint8Array(
      await crypto.subtle.decrypt(
        { name: 'AES-GCM', iv: buffer(ivBytes), additionalData: aad(descriptor) },
        aesKey,
        buffer(ctBytes)
      )
    )
  } catch (cause) {
    throw new Error('This grant does not open with this key: it is addressed to another key, or was altered', {
      cause,
    })
  }
}

/**
 * Pack the grant to deliver or store it
 *
 * ```text
 * { 0: v, 1: node, 2: owner (20 bytes), 3: groupKeyId (16 bytes),
 *   4: epk (65 bytes), 5: iv (12 bytes), 6: ct (48 bytes), * text: informational }
 * ```
 *
 * Fields with text keys carry anything informational added to the grant, such as
 * a piece's CID. These informational keys are not authenticated.
 */
export function encodeGrant<G extends Grant>(grant: G): Uint8Array {
  const { v, node, owner, groupKeyId, alg, epk, iv, ct, ...info } = grant
  const descriptor = canonical({ v, node, owner, groupKeyId })
  if (alg !== ALG) {
    throw new Error(`Unsupported grant algorithm: ${String(alg)}`)
  }
  const fields = new Map<number | string, unknown>([
    [FIELD.v, descriptor.v],
    [FIELD.node, descriptor.node],
    [FIELD.owner, hexToBytes(descriptor.owner)],
    [FIELD.groupKeyId, hexToBytes(descriptor.groupKeyId)],
    [FIELD.epk, grantBytes(epk, 'epk', 65)],
    [FIELD.iv, grantBytes(iv, 'iv', 12)],
    [FIELD.ct, grantBytes(ct, 'ct', KEY_LENGTH + 16)],
  ])
  for (const [key, value] of Object.entries(info)) {
    fields.set(key, value)
  }
  return encode(fields)
}

/**
 * Read a grant delivered as bytes, without opening it: to see what it names
 * before unwrapping, or to pass to {@link holdingOf}.
 *
 * @throws If the bytes are not one canonical CBOR map holding a version 2
 * grant, with every field the right type and size and no unknown numbered field.
 */
export function decodeGrant(bytes: Uint8Array): DecodedGrant {
  let map: unknown
  try {
    map = decode(bytes, STRICT)
  } catch (cause) {
    throw new Error('Not a grant: the bytes are not canonical CBOR', { cause })
  }
  // Exactly what encodeGrant writes: the decoded map must encode back to the same bytes. This refuses a
  // float `v` or reordered keys, which would otherwise decode, as `decodeArray` does for presentations.
  if (bytesToHex(encode(map)) !== bytesToHex(bytes)) {
    throw new Error('Not a grant: the bytes are not canonical CBOR')
  }
  if (!(map instanceof Map)) {
    throw new Error('Not a grant: expected a CBOR map')
  }
  const info: Record<string, unknown> = {}
  for (const [key, value] of map) {
    if (typeof key === 'string') {
      info[key] = value
    } else if (!Object.values(FIELD).includes(key)) {
      throw new Error(`Not a grant this version understands: unknown field ${String(key)}`)
    }
  }
  assertFormatVersion(map.get(FIELD.v), 'grant')
  const field = (key: number, name: string, length: number): Hex => {
    const value = map.get(key)
    if (!(value instanceof Uint8Array) || value.length !== length) {
      throw new Error(`A grant's ${name} must be ${length} bytes`)
    }
    return bytesToHex(value)
  }
  return {
    ...info,
    v: 2,
    node: text(map.get(FIELD.node), 'A grant node'),
    owner: field(FIELD.owner, 'owner', 20),
    groupKeyId: field(FIELD.groupKeyId, 'groupKeyId', 16),
    alg: ALG,
    epk: field(FIELD.epk, 'epk', 65),
    iv: field(FIELD.iv, 'iv', 12),
    ct: field(FIELD.ct, 'ct', KEY_LENGTH + 16),
  }
}

/** A fixed-length hex field of a grant, as bytes. */
function grantBytes(value: unknown, field: string, length: number): Uint8Array {
  const hex = text(value, `A grant's ${field}`)
  if (!/^0x[0-9a-fA-F]*$/.test(hex) || hex.length !== 2 + 2 * length) {
    throw new Error(`A grant's ${field} must be ${length} bytes of hex`)
  }
  return hexToBytes(hex as Hex)
}

/** SSK for key wraps */
const sharedSecret = (privateKey: Uint8Array, publicKey: Uint8Array): Uint8Array =>
  secp256k1.getSharedSecret(privateKey, publicKey, true).subarray(1)

/** Derive key encryption key from HKDF(shared ‖ epk ‖ pkR) */
function wrapKek(shared: Uint8Array, epk: Uint8Array, pkR: Uint8Array): Uint8Array {
  const ikm = new Uint8Array(shared.length + epk.length + pkR.length)
  ikm.set(shared, 0)
  ikm.set(epk, shared.length)
  ikm.set(pkR, shared.length + epk.length)
  return hkdf(sha256, ikm, undefined, WRAP_INFO, 32)
}

/**
 * Canonicalize a grant descriptor to ensure it authenticates on the other end.
 *
 * @throws If it is not a version this code understands, or a field is malformed.
 */
function canonical(d: GrantDescriptor): GrantDescriptor {
  assertFormatVersion(d.v, 'grant')
  const owner = text(d.owner, "A grant's owner").toLowerCase()
  if (!isAddress(owner, { strict: false })) {
    throw new Error(`A grant's owner must be an address, got ${JSON.stringify(d.owner)}`)
  }
  return {
    v: 2,
    node: canonicalNode(d.node),
    owner: owner as Address,
    groupKeyId: groupKeyId(d.groupKeyId),
  }
}

/**
 * The authenticated fields of a canonical descriptor, in a fixed order:
 * `[v, node, owner, groupKeyId]` as deterministic CBOR (RFC 8949 §4.2.1), with
 * the owner and group key as bytes, so every implementation produces the same
 * bytes. Exactly these four are covered; anything else carried alongside a
 * grant is informational and unauthenticated.
 */
const aad = (d: GrantDescriptor): ArrayBuffer =>
  buffer(encode([d.v, d.node, hexToBytes(d.owner), hexToBytes(d.groupKeyId)]))

/** Helper: WebCrypto takes ArrayBuffer-backed data; noble and viem return views. */
const buffer = (view: Uint8Array): ArrayBuffer =>
  view.buffer.slice(view.byteOffset, view.byteOffset + view.byteLength) as ArrayBuffer
