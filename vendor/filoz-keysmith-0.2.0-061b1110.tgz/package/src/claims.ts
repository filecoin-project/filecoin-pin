/**
 * Read claims: authenticated read delegation chains.
 *
 * A claim chain is the authorization half of a grant; the wrap is the key half.
 * The metadata elements, group concepts etc are identical.
 * Its root is an EIP-712 `ReadGrant` signed by the group key owner's wallet,
 * with an expiry; every later link is signed by the previous link's bearer,
 * and a request by the final bearer.
 *
 * A relying party checks the claims against the labels in a piece's FEE envelope
 * to check the encryption group matches and is legitimately delegated all the way
 * up to the group key root.
 *
 * In short:
 *   - Wallet signs root delegating to session key
 *   - Session key(s) can onwardly delegate narrower groups to other session keys
 *   - Final session key signs a request for a piece to prove it holds the key delegated to
 */
import { decode, encode } from 'cborg'
import { type Address, bytesToHex, getAddress, type Hex, hexToBytes, isAddress, recoverTypedDataAddress } from 'viem'
import { privateKeyToAccount } from 'viem/accounts'
import {
  assertFormatVersion,
  canonicalNode,
  commitment,
  DOMAIN,
  gatedOwner,
  grantDescriptor,
  groupKeyId,
  groupLabelOf,
  groupPath,
  holdingOf,
  keyForEnvelope,
  labelsGroupKeyId,
  type NodeKind,
  nodeKind,
  own,
  pieceSalt,
  writeTarget,
} from './derive.ts'
import type { Grant, GrantNode, GroupKeyRef } from './types.ts'
import { decodeGrant, encodeGrant, unwrapWith } from './wrap.ts'

const STRICT = {
  strict: true,
  useMaps: true,
  rejectDuplicateMapKeys: true,
  allowIndefinite: false,
  allowUndefined: false,
  allowBigInt: false,
} as const

export const MAX_CHAIN_LENGTH = 8 // Arbitrary, but need to keep it manageable including things like presentation in an HTTP header.
export const MAX_REQUEST_LIFETIME = 300 // 5 minutes replay window
const SKEW = 60 // Tolerance for clock skew, in seconds
const outsideRequestWindow = (expires: number, now: number) =>
  expires < now - SKEW || expires > now + MAX_REQUEST_LIFETIME + SKEW

/**
 * EIP-712 types for every link and for a request. The domain is Keysmith's
 * {@link DOMAIN}. A link's signature covers the fields it inherits from the
 * root, so a link cannot be moved under a root that differs in any of them.
 * Links name their parent by its bearer's address, not by hash, so a parent
 * can be re-issued without invalidating the links beneath it.
 */
export const READ_GRANT_TYPES = {
  ReadGrant: [
    { name: 'v', type: 'uint8' },
    { name: 'node', type: 'string' },
    { name: 'owner', type: 'address' },
    { name: 'groupKeyId', type: 'bytes16' },
    { name: 'bearer', type: 'address' },
    { name: 'maxDepth', type: 'uint8' },
    { name: 'chainId', type: 'uint256' },
    { name: 'keyCommitment', type: 'bytes16' },
    { name: 'groupKeyCommitment', type: 'bytes16' },
    { name: 'expires', type: 'uint64' },
  ],
} as const
export const READ_REQUEST_TYPES = {
  ReadRequest: [
    { name: 'chainId', type: 'uint256' },
    { name: 'pieceCid', type: 'bytes' },
    { name: 'expires', type: 'uint64' },
  ],
} as const

/** One link: what its bearer may read, and how much further they may delegate. */
export interface Claim {
  /** A {@link GrantNode}, as signed. */
  node: string
  /** Who may present this link, and sign the next one. */
  bearer: Address
  /** Links the bearer may add below this one. */
  maxDepth: number
  /** First 16 bytes of the node key's commitment: what the bearer checks after unwrapping. */
  keyCommitment: Hex
  /** EIP-712: the owner's on the root, the previous bearer's on every later link. */
  signature: Hex
  /** Where a piece link's piece lives. A locator only: not signed, never decided on. */
  pieceCid?: Uint8Array
}

/** A chain, root first, with the fields every link inherits from the root. */
export interface ClaimChain {
  owner: Address // The group key owner, whose wallet signs the root
  groupKeyId: Hex // Spelled as in `foc/gkid`
  chainId: bigint // The network the claims are for, so a header cannot be replayed on another
  groupKeyCommitment: Hex // `foc/kc` without its `v2.` prefix
  expires: number // Unix seconds. The whole chain stops working then
  links: Claim[] // Root first
}

/** A request for one piece, from whichever provider holds it, signed by the chain's final bearer. */
export interface ReadRequest {
  pieceCid: Uint8Array // The piece asked for, as a binary CID
  expires: number // Unix seconds; at most MAX_REQUEST_LIFETIME ahead
  signature: Hex // The final bearer's EIP-712 ReadRequest signature
}

/**
 * The labels a provider read from a piece's FEE envelope. `foc/v` may be absent, 2 or "2";
 * keysmith 0.1.0 labels (`foc/v` 1, as a number or string, or `foc/ks`) and any other value are refused.
 * Hand-written: fields are plain strings (not `Address`/`Hex`) and `foc/own` is optional.
 */
export type PieceLabels = {
  'foc/own'?: string // The group key owner; absent or falsy means not gated
  'foc/gkid': string // The group key id label
  'foc/group'?: string // The group path label, if any
  'foc/salt': string // Names the piece for a piece link
}

const rawLabels = (piece: PieceLabels) => piece as Readonly<Record<string, unknown>>

/** The canonical group key id the labels name. Lenient on `foc/v`: a provider may pass labels parsed from JSON. */
const idOf = (piece: PieceLabels) => labelsGroupKeyId(rawLabels(piece), { lenient: true })

/** Labels as envelope metadata. */
const asMetadata = (piece: PieceLabels) => ({ ...piece, 'foc/v': 2 })

/** The canonical group path the labels name, if any. Reads only the group label. */
const groupOf = (piece: PieceLabels) => groupLabelOf(rawLabels(piece))

/** Anything that signs EIP-712 typed data: a viem account or wallet client. */
export interface ClaimSigner {
  signTypedData: (args: any) => Promise<Hex>
}

/** A key's commitment as the 16 bytes a claim carries. */
export const keyCommitmentOf = (key: Uint8Array): Hex => `0x${commitment(key).slice('v2.'.length)}`

function depth(value: number): number {
  if (!Number.isInteger(value) || value < 0 || value > 255) throw new Error(`maxDepth must be 0 to 255, got ${value}`)
  return value
}

/**
 * Claims expire; keys do not. A gating provider refuses an expired chain, so everything that would
 * *use* a claim refuses it too, with a clear reason, while opening and decrypting with the key still works.
 */
function assertLive(chain: Pick<ClaimChain, 'expires'>, now: number, purpose: string): void {
  if (chain.expires <= now) {
    throw new Error(
      `The claim expired at ${new Date(chain.expires * 1000).toISOString()}: get a new grant to ${purpose}`
    )
  }
}

function unixSeconds(value: number, what: string): number {
  if (!Number.isSafeInteger(value) || value < 0) throw new Error(`${what} must be unix seconds, got ${value}`)
  return value
}

const grantMessage = (chain: ClaimChain, link: Omit<Claim, 'signature'>) => ({
  v: 2,
  node: link.node,
  owner: chain.owner,
  groupKeyId: chain.groupKeyId,
  bearer: link.bearer,
  maxDepth: link.maxDepth,
  chainId: chain.chainId,
  keyCommitment: link.keyCommitment,
  groupKeyCommitment: chain.groupKeyCommitment,
  expires: BigInt(chain.expires),
})

// secp256k1's group order. A signature's s may be replaced by N - s (with v flipped) and still verify,
// so only the low-s form is accepted, as EIP-2 requires of Ethereum transactions.
const N = 0xfffffffffffffffffffffffffffffffebaaedce6af48a03bbfd25e8cd0364141n

/** A signature in the one form Keysmith writes and accepts: r ‖ s ‖ v, s at most N/2, v 27 or 28. */
function normalSignature(signature: Hex): Hex {
  const bytes = hexToBytes(signature)
  if (bytes.length !== 65) throw new Error(`A signature is 65 bytes, got ${bytes.length}`)
  let v = (bytes[64] as number) < 27 ? (bytes[64] as number) + 27 : (bytes[64] as number)
  let s = BigInt(bytesToHex(bytes.subarray(32, 64)))
  if (v !== 27 && v !== 28) throw new Error(`A signature's v must be 27 or 28 (or 0 or 1), got ${bytes[64]}`)
  if (s > N >> 1n) {
    s = N - s
    v = v === 27 ? 28 : 27
  }
  return `${bytesToHex(bytes.subarray(0, 32))}${s.toString(16).padStart(64, '0')}${v.toString(16)}`
}

const signLink = async (signer: ClaimSigner, chain: ClaimChain, link: Omit<Claim, 'signature'>) =>
  normalSignature(
    await signer.signTypedData({
      domain: DOMAIN,
      types: READ_GRANT_TYPES,
      primaryType: 'ReadGrant',
      message: grantMessage(chain, link),
    })
  )

const recoverIssuer = (chain: ClaimChain, link: Claim) =>
  recoverTypedDataAddress({
    domain: DOMAIN,
    types: READ_GRANT_TYPES,
    primaryType: 'ReadGrant',
    message: grantMessage(chain, link),
    signature: link.signature,
  })

/**
 * The key for `node`, derived from a key the caller holds for `heldNode`, so a
 * claim can only ever commit to a key that really sits below its issuer's.
 * A piece node needs the piece's labels, which must name that piece in this group key.
 */
function keyBelow(
  heldKey: Uint8Array,
  heldNode: string,
  node: string,
  ref: { owner: Address; groupKeyId: Hex },
  piece: PieceLabels | undefined
): Uint8Array {
  const target = nodeKind(node)
  if (target.kind === 'piece') {
    if (!piece) throw new Error(`${node} names a piece: deriving its key needs the piece's labels`)
    if (pieceNodeOf(piece) !== `piece:${target.salt}` || idOf(piece) !== ref.groupKeyId) {
      throw new Error(`The piece labels given are not for ${node} in group key ${ref.groupKeyId}`)
    }
    return keyForEnvelope(heldKey, asMetadata(piece), holdingOf({ node: heldNode }))
  }
  const group = target.kind === 'group' ? target.path : undefined
  return writeTarget(grantDescriptor(ref, heldNode as GrantNode), heldKey, group).key.slice()
}

/**
 * The root of a chain, signed by the owner's wallet: one EIP-712 prompt.
 * Derives the bearer's node key from the group key, so the root cannot
 * commit to a wrong one, and hands it back to wrap for the bearer.
 * When the bearer is a session key, set `expires` to the session key's expiry.
 *
 * @throws If `signer` is not the owner.
 */
export async function rootClaim(
  owner: ClaimSigner,
  input: {
    owner: Address
    groupKeyId: Hex
    chainId: bigint
    groupKey: Uint8Array // The group key, from deriveGroupKey()
    node: string // A GrantNode
    bearer: Address
    maxDepth: number
    expires: number // Unix seconds. Required: providers check no revocation, so this is what ends the claim
    piece?: PieceLabels // For a piece node: the piece's envelope labels
    pieceCid?: Uint8Array // Where a piece root's piece lives: a locator only, not signed
    now?: number // Unix seconds; defaults to now
  }
): Promise<{ chain: ClaimChain; nodeKey: Uint8Array }> {
  if (!isAddress(input.owner) || !isAddress(input.bearer)) throw new Error('owner and bearer must be addresses')
  const ref = { owner: getAddress(input.owner), groupKeyId: groupKeyId(input.groupKeyId) }
  const node = canonicalNode(input.node)
  const nodeKey = keyBelow(input.groupKey, 'groupKey', node, ref, input.piece)
  const link = {
    node,
    bearer: getAddress(input.bearer),
    maxDepth: depth(input.maxDepth),
    keyCommitment: keyCommitmentOf(nodeKey),
    ...(input.pieceCid ? { pieceCid: input.pieceCid } : {}),
  }
  const chain: ClaimChain = {
    ...ref,
    chainId: input.chainId,
    groupKeyCommitment: keyCommitmentOf(input.groupKey),
    expires: unixSeconds(input.expires, 'expires'),
    links: [],
  }
  assertLive(chain, input.now ?? Math.floor(Date.now() / 1000), 'issue a root')
  const signature = await signLink(owner, chain, link)
  const root = { ...link, signature }
  if ((await recoverIssuer(chain, root)) !== chain.owner) throw new Error(`The root must be signed by ${chain.owner}`)
  return { chain: { ...chain, links: [root] }, nodeKey }
}

/**
 * Delegate: the chain's final bearer signs a narrower link for `bearer`.
 * Takes the key the bearer holds for its own link, checks it against that
 * link's commitment, and derives the child's key from it, so an honest
 * delegate cannot commit to a wrong key. Hands the child key back to wrap.
 * A piece link needs the piece's labels, to check the parent's node reaches it.
 */
export async function delegateClaim(
  signer: ClaimSigner,
  chain: ClaimChain,
  input: {
    parentKey: Uint8Array // The key for the final link's node, as openDelivery() returned it
    node: string // A GrantNode
    bearer: Address
    maxDepth: number
    pieceCid?: Uint8Array
    piece?: PieceLabels
    now?: number // Unix seconds; defaults to now
  }
): Promise<{ chain: ClaimChain; nodeKey: Uint8Array }> {
  const parent = chain.links.at(-1)
  if (!parent) throw new Error('A chain has at least one link')
  assertLive(chain, input.now ?? Math.floor(Date.now() / 1000), 'delegate')
  if (chain.links.length >= MAX_CHAIN_LENGTH) throw new Error(`A chain has at most ${MAX_CHAIN_LENGTH} links`)
  if (keyCommitmentOf(input.parentKey) !== parent.keyCommitment) {
    throw new Error(`parentKey is not the key link ${chain.links.length - 1} commits to`)
  }
  const node = canonicalNode(input.node)
  const step = { node, bearer: getAddress(input.bearer), maxDepth: depth(input.maxDepth) }
  checkStep(parent, step, input.piece, chain.links.length)
  const nodeKey = keyBelow(input.parentKey, parent.node, node, chain, input.piece)
  const link = {
    ...step,
    keyCommitment: keyCommitmentOf(nodeKey),
    ...(input.pieceCid ? { pieceCid: input.pieceCid } : {}),
  }
  const signature = await signLink(signer, chain, link)
  return { chain: { ...chain, links: [...chain.links, { ...link, signature }] }, nodeKey }
}

/**
 * Sign a request for one piece, as the chain's final bearer. Any provider holding it may serve it.
 *
 * @throws If the chain has expired, or `expires` is outside the window a provider accepts.
 */
export async function signRequest(
  signer: ClaimSigner,
  chain: ClaimChain,
  input: { pieceCid: Uint8Array; expires: number; now?: number }
): Promise<ReadRequest> {
  const now = input.now ?? Math.floor(Date.now() / 1000)
  if (!Number.isSafeInteger(input.expires) || !Number.isSafeInteger(now)) {
    throw new Error('A request expiry and now must be whole Unix seconds')
  }
  assertLive(chain, now, 'fetch from a gating provider')
  if (outsideRequestWindow(input.expires, now)) {
    throw new Error(`A request must expire within ${MAX_REQUEST_LIFETIME} seconds, and not in the past`)
  }
  const signature = normalSignature(
    await signer.signTypedData({
      domain: DOMAIN,
      types: READ_REQUEST_TYPES,
      primaryType: 'ReadRequest',
      message: {
        chainId: chain.chainId,
        pieceCid: bytesToHex(input.pieceCid),
        expires: BigInt(input.expires),
      },
    })
  )
  return { pieceCid: input.pieceCid, expires: input.expires, signature }
}

// ── coverage ─────────────────────────────────────────────────────────────

const within = (parent: string, child: string) => child === parent || child.startsWith(`${parent}/`)

/**
 * The piece node naming these labels' piece, in canonical form: labels are compared canonically, never as raw text.
 * Reads only `foc/salt`.
 */
const pieceNodeOf = (piece: PieceLabels) => `piece:${pieceSalt(own(rawLabels(piece), 'foc/salt'))}`

/** Whether a parsed node reaches a piece with this piece node and group: the one rule behind `reaches` and `pickGrant`. */
function reachesKind(held: NodeKind, pieceNode: string | undefined, group: string | undefined): boolean {
  if (held.kind === 'groupKey') return true
  if (held.kind === 'piece') return `piece:${held.salt}` === pieceNode
  return group != null && within(held.path, group)
}

/** Whether `node` reaches the piece these labels describe. Reads only the label the node's kind needs. */
export function reaches(node: string, piece: PieceLabels): boolean {
  const k = nodeKind(node)
  const pieceNode = k.kind === 'piece' ? pieceNodeOf(piece) : undefined
  const group = k.kind === 'group' ? groupOf(piece) : undefined
  return reachesKind(k, pieceNode, group)
}

/** What a grant is picked for: reading one piece, or writing (or reading) under a group of a group key. */
export type GrantTarget = { piece: PieceLabels } | (GroupKeyRef & { group: string })

/**
 * The narrowest held grant that reaches `target`: a piece grant before a group grant, a deeper group before a
 * shallower one, the group key last; on a tie, the one that expires last. Grants for another network or group key,
 * or expired ones, or whose node does not parse, are skipped. Undefined when none reaches it: ask for a grant to that group or piece.
 *
 * Takes anything carrying a verified `claim`, such as what `openDelivery` returns.
 *
 * Grants are matched to one owner, never to any owner: a grant's owner and group key id are public, so
 * anyone can root a grant under another wallet's group key id. A group target names its owner. A piece
 * target takes it from the piece's `foc/own`; a piece without one (not gated) needs `options.owner`. When
 * both are present they must match.
 *
 * @throws If no owner can be fixed, `options.owner` contradicts the piece's `foc/own`, or a label is malformed.
 */
export function pickGrant<T extends { claim: VerifiedClaim }>(
  grants: readonly T[],
  target: GrantTarget,
  options: { chainId: bigint; now?: number; owner?: Address }
): T | undefined {
  // A stale `scope` would read as "no group", and could pick a grant that is too broad.
  if ('scope' in target) throw new Error('pickGrant takes `group`, not `scope`')
  const now = options.now ?? Math.floor(Date.now() / 1000)
  // Validate the target once, so bad input fails the same way whatever grants are held
  const owner = expectedOwner(target, options.owner)
  const id = 'piece' in target ? idOf(target.piece) : groupKeyId(target.groupKeyId)
  let group: string | undefined
  let pieceNode: string | undefined
  if ('piece' in target) {
    pieceNode = pieceNodeOf(target.piece) // Refuses a malformed salt, though only a piece grant would read it
    group = groupOf(target.piece)
  } else if (target.group != null) group = groupPath(target.group)
  let best: T | undefined
  let bestRank = 0
  for (const held of grants) {
    const { claim } = held
    if (claim.chainId !== options.chainId || claim.expires <= now || claim.groupKeyId !== id) continue
    if (owner !== claim.owner) continue
    // A node that does not parse (a stored 0.1.0 claim, say) reaches nothing: skip it
    const kind = tryNodeKind(claim.node)
    if (kind === undefined || !reachesKind(kind, pieceNode, group)) continue
    const rank = narrowness(kind)
    if (!best || rank > bestRank || (rank === bestRank && claim.expires > best.claim.expires)) {
      best = held
      bestRank = rank
    }
  }
  return best
}

/** The one owner whose grants `pickGrant` may pick: the target's own, checked against `pinned` when both exist. */
function expectedOwner(target: GrantTarget, pinned: unknown): Address {
  const named =
    'piece' in target
      ? gatedOwner(own(rawLabels(target.piece), 'foc/own'))
      : asOwner(target.owner, 'pickGrant needs the group key owner')
  const fixed = pinned == null ? undefined : asOwner(pinned, 'pickGrant options.owner must be an address')
  const owner = named ?? fixed
  if (owner === undefined) throw new Error('pickGrant needs the expected owner for a piece without foc/own')
  if (fixed !== undefined && getAddress(owner) !== fixed) {
    throw new Error(`pickGrant options.owner ${fixed} does not match the owner ${getAddress(owner)}`)
  }
  return getAddress(owner)
}

const asOwner = (value: unknown, what: string): Address => {
  if (typeof value !== 'string' || !isAddress(value, { strict: false })) {
    throw new Error(`${what}, got ${JSON.stringify(value)}`)
  }
  return getAddress(value)
}

function tryNodeKind(node: string): NodeKind | undefined {
  try {
    return nodeKind(node)
  } catch {
    return undefined
  }
}

// the group key 0, 'group:a/b' 2, any piece above every group
const narrowness = (k: NodeKind) => {
  if (k.kind === 'groupKey') return 0
  if (k.kind === 'piece') return Number.POSITIVE_INFINITY
  return k.path.split('/').length
}

/**
 * The `Authorization` header for one gated request: a request for `pieceCid` signed by the chain's final bearer,
 * presented with its chain. Make a fresh one per fetch; it expires `expiresIn` seconds after `now` (default 240).
 *
 * @throws As `signRequest` does: an expired chain, or an expiry the gate would refuse.
 */
export async function authorizationHeader(
  signer: ClaimSigner,
  chain: ClaimChain,
  input: { pieceCid: Uint8Array; expiresIn?: number; now?: number }
): Promise<string> {
  const now = input.now ?? Math.floor(Date.now() / 1000)
  const expires = now + (input.expiresIn ?? MAX_REQUEST_LIFETIME - SKEW)
  const request = await signRequest(signer, chain, { pieceCid: input.pieceCid, expires, now })
  return `FOC-Grant ${base64url(encodePresentation(chain, request))}`
}

function base64url(bytes: Uint8Array): string {
  let binary = ''
  for (const byte of bytes) binary += String.fromCharCode(byte)
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '')
}

/** Check one step down a chain: the child no wider than its parent, and within its depth. */
function checkStep(
  parent: Pick<Claim, 'node' | 'maxDepth'>,
  child: Pick<Claim, 'node' | 'maxDepth'>,
  piece: PieceLabels | undefined,
  index: number
): void {
  if (parent.maxDepth < 1 || child.maxDepth > parent.maxDepth - 1) {
    throw new Error(`Link ${index} exceeds link ${index - 1}'s maxDepth`)
  }
  const from = nodeKind(parent.node)
  const to = nodeKind(child.node)
  let narrower: boolean
  if (from.kind === 'groupKey') narrower = true
  else if (to.kind === 'piece') {
    if (!piece) throw new Error(`Link ${index} names a piece: checking it needs the piece's labels`)
    narrower = `piece:${to.salt}` === pieceNodeOf(piece) && reaches(parent.node, piece)
  } else narrower = from.kind === 'group' && to.kind === 'group' && within(from.path, to.path)
  if (!narrower) throw new Error(`Link ${index} widens ${parent.node} to ${child.node}`)
}

/** The final claim of a verified chain. */
export interface VerifiedClaim {
  owner: Address
  groupKeyId: Hex
  chainId: bigint
  groupKeyCommitment: Hex
  expires: number
  node: string
  bearer: Address
  keyCommitment: Hex
}

/**
 * Check a chain with nothing but the chain: the root signed by the owner and
 * unexpired, every later link signed by the previous bearer and no wider than
 * it. Pass `piece` when a link names a piece.
 *
 * @throws With the reason the chain is refused.
 */
export async function verifyChain(
  chain: ClaimChain,
  options: { now?: number; piece?: PieceLabels } = {}
): Promise<VerifiedClaim> {
  const now = options.now ?? Math.floor(Date.now() / 1000)
  if (chain.expires < now - SKEW)
    throw new Error(`The chain expired at ${new Date(chain.expires * 1000).toISOString()}`)
  return verifyLinks(chain, options.piece)
}

/** Every check of a chain except its expiry. */
async function verifyLinks(chain: ClaimChain, piece: PieceLabels | undefined): Promise<VerifiedClaim> {
  const { links } = chain
  if (links.length < 1 || links.length > MAX_CHAIN_LENGTH) throw new Error(`A chain has 1 to ${MAX_CHAIN_LENGTH} links`)
  const root = links[0] as Claim
  if (nodeKind(root.node).kind === 'groupKey' && root.keyCommitment !== chain.groupKeyCommitment) {
    throw new Error('A group key root must carry the group key commitment')
  }
  if ((await recoverIssuer(chain, root)) !== chain.owner) throw new Error('The root is not signed by the owner')
  for (const [i, link] of links.entries()) {
    if (i === 0) continue
    const parent = links[i - 1] as Claim
    if ((await recoverIssuer(chain, link)) !== parent.bearer) {
      throw new Error(`Link ${i} is not signed by link ${i - 1}'s bearer`)
    }
    checkStep(parent, link, piece, i)
  }
  const last = links.at(-1) as Claim
  return {
    owner: chain.owner,
    groupKeyId: chain.groupKeyId,
    chainId: chain.chainId,
    groupKeyCommitment: chain.groupKeyCommitment,
    expires: chain.expires,
    node: last.node,
    bearer: last.bearer,
    keyCommitment: last.keyCommitment,
  }
}

/**
 * What a gating provider checks on a request, with only the header and the
 * piece's labels: the chain, the request's piece, lifetime and signer, and that the final node reaches the piece. A piece whose
 * `foc/own` is absent or falsy is not gated.
 *
 * @throws With the reason the request is refused.
 */
export async function verifyPresentation(
  bytes: Uint8Array,
  options: {
    pieceCid: Uint8Array
    piece: PieceLabels
    chainId: bigint // The provider's chain; a header for another network is refused
    now?: number // Unix seconds; defaults to now
  }
): Promise<VerifiedClaim> {
  const { chain, request } = decodePresentation(bytes)
  const now = options.now ?? Math.floor(Date.now() / 1000)
  const claim = await verifyChain(chain, { now, piece: options.piece })
  if (chain.chainId !== options.chainId) throw new Error('The chain names another network')
  if (bytesToHex(request.pieceCid) !== bytesToHex(options.pieceCid)) throw new Error('The request names another piece')
  if (outsideRequestWindow(request.expires, now)) {
    throw new Error('The request has expired, or is valid for too long')
  }
  const signer = await recoverTypedDataAddress({
    domain: DOMAIN,
    types: READ_REQUEST_TYPES,
    primaryType: 'ReadRequest',
    message: {
      chainId: chain.chainId,
      pieceCid: bytesToHex(request.pieceCid),
      expires: BigInt(request.expires),
    },
    signature: request.signature,
  })
  if (signer !== claim.bearer) throw new Error('The request is not signed by the final bearer')
  const { piece } = options
  const owner = gatedOwner(own(rawLabels(piece), 'foc/own')) // Throws on a truthy `foc/own` that is not an address
  if (owner === undefined) return claim // Not gated; other labels are not read
  if (owner.toLowerCase() !== claim.owner.toLowerCase() || idOf(piece) !== claim.groupKeyId) {
    throw new Error('The piece belongs to another owner or group key')
  }
  pieceSalt(own(rawLabels(piece), 'foc/salt')) // No key opens a gated piece without a valid salt
  if (!reaches(claim.node, piece)) {
    throw new Error(`${claim.node} does not reach this piece (group ${own(rawLabels(piece), 'foc/group') ?? '(none)'})`)
  }
  return claim
}

/**
 * Open a delivery as its final bearer: verify the chain, unwrap the key, and
 * check it against the commitment in its claim, which the owner (or the
 * delegate above) signed. The group key commitment comes back too, for a bearer
 * that writes the group key's first datasets.
 *
 * An expired delivery still opens: a key cannot expire, so decrypting with it
 * keeps working. `expired` says the claim is spent, and `signRequest` and
 * `delegateClaim` refuse it; get a new grant before fetching from a gating
 * provider or sharing onward.
 *
 * @throws With the reason the delivery is refused.
 */
export async function openDelivery(
  privateKey: Hex,
  bytes: Uint8Array,
  options: { now?: number; piece?: PieceLabels } = {}
): Promise<{ chain: ClaimChain; grant: Grant; claim: VerifiedClaim; key: Uint8Array; expired: boolean }> {
  const { chain, grant } = decodeDelivery(bytes)
  const claim = await verifyLinks(chain, options.piece)
  if (claim.bearer !== privateKeyToAccount(privateKey).address) throw new Error('This delivery is for another bearer')
  assertGrantNamesClaim(grant, claim)
  const key = await unwrapWith(privateKey, grant)
  if (keyCommitmentOf(key) !== claim.keyCommitment) {
    throw new Error('The delivered key does not match the commitment in its claim')
  }
  return { chain, grant, claim, key, expired: chain.expires <= (options.now ?? Math.floor(Date.now() / 1000)) }
}

/** A delivery's grant must name what its final link names: the wrap's descriptor and the claim are one node. */
function assertGrantNamesClaim(grant: Grant, claim: { owner: Address; groupKeyId: Hex; node: string }): void {
  if (
    getAddress(grant.owner) !== claim.owner ||
    grant.groupKeyId.toLowerCase() !== claim.groupKeyId ||
    canonicalNode(grant.node) !== canonicalNode(claim.node)
  ) {
    throw new Error("The delivery's key is for another node than its claim")
  }
}

// ── CBOR ─────────────────────────────────────────────────────────────────

// Link fields: 0 v · 1 node · 2 owner · 3 groupKeyId · 4 bearer · 5 maxDepth · 6 chainId · 7 keyCommitment
// · 8 signature · 9 pieceCid (locator) · 10 groupKeyCommitment · 11 expires. 2, 3, 6, 10 and 11 are on the root only.
const ROOT_ONLY = [2, 3, 6, 10, 11]

function encodeChainLinks(chain: ClaimChain): Map<number, unknown>[] {
  return chain.links.map((link, i) => {
    const fields = new Map<number, unknown>([
      [0, 2],
      [1, link.node],
      [4, hexToBytes(link.bearer)],
      [5, link.maxDepth],
      [7, hexToBytes(link.keyCommitment)],
      [8, hexToBytes(link.signature)],
    ])
    if (i === 0) {
      fields.set(2, hexToBytes(chain.owner))
      fields.set(3, hexToBytes(chain.groupKeyId))
      fields.set(6, Number(chain.chainId))
      fields.set(10, hexToBytes(chain.groupKeyCommitment))
      fields.set(11, chain.expires)
    }
    if (link.pieceCid) fields.set(9, link.pieceCid)
    return new Map([...fields].sort(([a], [b]) => a - b))
  })
}

function bytesField(map: Map<unknown, unknown>, key: number, length: number, what: string): Hex {
  const value = map.get(key)
  if (!(value instanceof Uint8Array) || value.length !== length) throw new Error(`${what} must be ${length} bytes`)
  return bytesToHex(value)
}

function signatureField(map: Map<unknown, unknown>, key: number, what: string): Hex {
  const signature = bytesField(map, key, 65, what)
  if (normalSignature(signature) !== signature) throw new Error(`${what} must have a low s and v = 27 or 28`)
  return signature
}

function uintField(map: Map<unknown, unknown>, key: number, what: string): number {
  const value = map.get(key)
  if (typeof value !== 'number' || !Number.isSafeInteger(value) || value < 0) {
    throw new Error(`${what} must be an unsigned integer`)
  }
  return value
}

function decodeChainLinks(value: unknown): ClaimChain {
  if (!Array.isArray(value) || value.length < 1 || value.length > MAX_CHAIN_LENGTH) {
    throw new Error(`A chain is an array of 1 to ${MAX_CHAIN_LENGTH} links`)
  }
  const maps = value.map((link, i) => {
    if (!(link instanceof Map)) throw new Error(`Link ${i} is not a map`)
    for (const key of link.keys()) {
      if (typeof key !== 'number' || key < 0 || key > 11)
        throw new Error(`Link ${i} has an unknown field ${String(key)}`)
      if (i > 0 && ROOT_ONLY.includes(key)) throw new Error(`Link ${i} repeats a root-only field`)
    }
    assertFormatVersion(link.get(0), `claim link ${i}`)
    return link as Map<number, unknown>
  })
  const root = maps[0] as Map<number, unknown>
  return {
    owner: getAddress(bytesField(root, 2, 20, 'owner')),
    groupKeyId: bytesField(root, 3, 16, 'groupKeyId'),
    chainId: BigInt(uintField(root, 6, 'The root chain id')),
    groupKeyCommitment: bytesField(root, 10, 16, 'groupKeyCommitment'),
    expires: uintField(root, 11, 'The root expiry'),
    links: maps.map((link, i) => {
      const node = link.get(1)
      if (typeof node !== 'string' || canonicalNode(node) !== node)
        throw new Error(`Link ${i} has a non-canonical node`)
      const pieceCid = link.get(9)
      if (pieceCid !== undefined && !(pieceCid instanceof Uint8Array))
        throw new Error(`Link ${i}'s pieceCid must be bytes`)
      return {
        node,
        bearer: getAddress(bytesField(link, 4, 20, `Link ${i}'s bearer`)),
        maxDepth: depth(uintField(link, 5, `Link ${i}'s maxDepth`)),
        keyCommitment: bytesField(link, 7, 16, `Link ${i}'s keyCommitment`),
        signature: signatureField(link, 8, `Link ${i}'s signature`),
        ...(pieceCid ? { pieceCid } : {}),
      }
    }),
  }
}

function decodeArray(bytes: Uint8Array, what: string): unknown[] {
  let value: unknown
  try {
    value = decode(bytes, STRICT)
  } catch (cause) {
    throw new Error(`Not a ${what}: the bytes are not canonical CBOR`, { cause })
  }
  // Exactly core deterministic CBOR (RFC 8949 §4.2.1): what the bytes decode to must encode back to the
  // same bytes. This refuses map keys out of order and ill-formed UTF-8 text, which would otherwise decode.
  if (bytesToHex(encode(value)) !== bytesToHex(bytes)) {
    throw new Error(`Not a ${what}: the bytes are not canonical CBOR`)
  }
  if (!Array.isArray(value) || value.length !== 3) throw new Error(`Not a version 2 ${what}`)
  assertFormatVersion(value[0], what)
  return value
}

/**
 * A delivery: sent once to a new bearer, never to a provider. Carries the v2 grant that wraps the key.
 * The grant must name the chain's final node, owner and group key; that the wrapped key matches the
 * link's commitment is checked by `openDelivery`, which holds the private key to unwrap it.
 */
export function encodeDelivery(chain: ClaimChain, grant: Grant): Uint8Array {
  const last = chain.links.at(-1)
  if (!last) throw new Error('A chain has at least one link')
  assertGrantNamesClaim(grant, { owner: chain.owner, groupKeyId: chain.groupKeyId, node: last.node })
  return encode([2, encodeChainLinks(chain), encodeGrant(grant)])
}

export function decodeDelivery(bytes: Uint8Array): { chain: ClaimChain; grant: Grant } {
  const [, chain, grant] = decodeArray(bytes, 'delivery')
  if (!(grant instanceof Uint8Array)) throw new Error("A delivery's grant must be bytes")
  return { chain: decodeChainLinks(chain), grant: decodeGrant(grant) }
}

/** A presentation: sent to a provider with each gated request, as `Authorization: FOC-Grant <base64url>`. */
export function encodePresentation(chain: ClaimChain, request: ReadRequest): Uint8Array {
  const req = new Map<number, unknown>([
    [0, request.pieceCid],
    [1, request.expires],
    [2, hexToBytes(request.signature)],
  ])
  return encode([2, encodeChainLinks(chain), req])
}

export function decodePresentation(bytes: Uint8Array): { chain: ClaimChain; request: ReadRequest } {
  const [, chain, req] = decodeArray(bytes, 'presentation')
  if (!(req instanceof Map)) throw new Error('A request is a map')
  for (const key of req.keys()) {
    if (key !== 0 && key !== 1 && key !== 2) throw new Error(`The request has an unknown field ${String(key)}`)
  }
  const pieceCid = req.get(0)
  if (!(pieceCid instanceof Uint8Array)) throw new Error('A request needs a piece CID')
  return {
    chain: decodeChainLinks(chain),
    request: {
      pieceCid,
      expires: uintField(req, 1, "The request's expiry"),
      signature: signatureField(req as Map<number, unknown>, 2, "The request's signature"),
    },
  }
}
